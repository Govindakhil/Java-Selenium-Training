package com.cg.service;

import com.cg.bean.Address;
import com.cg.bean.Employee;

public class EmployeeSchedular {

	private Employee[] employees = new Employee[10];
	

	private int counterEmployee;

	
	public String addEmployee(int empId, String name, String designation, double salary, String city ) {
		
		if (employeeIdValidator(empId) == true) {
		employees[counterEmployee] = new Employee();
		employees[counterEmployee].setEmpId(empId);
		employees[counterEmployee].setName(name);
		employees[counterEmployee].setDesignation(designation);
		employees[counterEmployee].setSalary(salary);
		Address address= new Address();
		address.setCity(city);
		employees[counterEmployee].setAddress(address);
		counterEmployee++;
		return "employee deatils added successfully";
	}
		else {
			return " ***********  Employee id already exists  ********** ";
		}
	}

	public void displayAllemployeeDetails() {

		for (int i = 0; i < counterEmployee; i++) {
			System.out.println(employees[i].getEmpId());
			System.out.println(employees[i].getName());
			System.out.println(employees[i].getDesignation());
			System.out.println(employees[i].getSalary());
			System.out.println(employees[i].getAddress());
			
		}
	}

	public void displayAllEmployeeById(int empId) {

		for (int i = 0; i < counterEmployee; i++) {
			if (employees[i].getEmpId() == empId) {
				System.out.println(employees[i].getEmpId());
				System.out.println(employees[i].getName());
				System.out.println(employees[i].getDesignation());
				System.out.println(employees[i].getSalary());
				System.out.println(employees[i].getAddress());
			}
		}

	}
	
	public void displayAllEmployeeByDesignation(String designation) {

		for (int i = 0; i < counterEmployee; i++) {
			if (employees[i].getDesignation().equals(designation)) {
				System.out.println(employees[i].getEmpId());
				System.out.println(employees[i].getName());
				System.out.println(employees[i].getDesignation());
				System.out.println(employees[i].getSalary());
				System.out.println(employees[i].getAddress());
			}
		}

	}
	
	public boolean employeeIdValidator(int empId) {
		for (int i = 0; i < counterEmployee; i++) {
			if (employees[i].getEmpId() == empId) {
				return false;
			}
			
		}
		return true;
	}

}
