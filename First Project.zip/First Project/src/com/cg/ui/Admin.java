package com.cg.ui;

import java.util.Scanner;

import com.cg.service.EmployeeSchedular;

public class Admin {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		EmployeeSchedular e = new EmployeeSchedular();

		int n;

		do {
			System.out.println("Menu");
			System.out.println("1.add employee");
			System.out.println("2.display all employee");
			System.out.println("3.display employee by id");
			System.out.println("4.display employee by designation");
			System.out.println("5.exit");
			n = sc.nextInt();

			switch (n) {
			case 1:

				System.out.println("Enter the empId");
				int empId = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the employee Name");
				String name = sc.nextLine();
				System.out.println("Enter the employee Designation");
				String designation = sc.nextLine();
				System.out.println("Enter the employee Salary");
				double salary = sc.nextDouble();
				System.out.println("Enter the city");
				String city = sc.next();
				
				System.out.println(e.addEmployee(empId, name, designation, salary, city));
				break;

			case 2:

				e.displayAllemployeeDetails();
				break;

			case 3:
				System.out.println("Enter the employee id");
				int empId1 = sc.nextInt();
				e.displayAllEmployeeById(empId1);
				break;

			case 4:
				System.out.println("Enter the employee designation");
				String designation1 = sc.next();
				e.displayAllEmployeeByDesignation(designation1);
				break;
			
			default:
				break;

			}

		} while (n<5);
	}
}
