package com.capgemini.thirdproject;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonNew {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\akhil\\Downloads\\chromedriver_win32\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("http://www.google.com");
		String title = driver.getTitle();
		driver.manage().window().maximize();
		Thread.sleep(2000);

		WebElement search = driver.findElement(By.name("q"));
		search.sendKeys("Amazon");
		search.submit();

		WebElement search2 = driver.findElement(By.xpath("//*[text()='Amazon.in']"));
		search2.click();

		WebElement search3 = driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']"));
		search3.sendKeys("Redmi 7");
		search3.submit();

		WebElement select = driver.findElement(By.partialLinkText("Redmi 7"));
		select.click();

		Set<String> handles = driver.getWindowHandles();
		String handle1 = driver.getWindowHandle();
		handles.remove(handle1);

		String handle = handles.iterator().next();
		String handle2 = "";
		if (handle != handle1) {
			handle2 = handle;
			driver.switchTo().window(handle2);
			System.out.println(handle2);
		}

		WebElement cart = driver.findElement(By.id("add-to-cart-button"));
		cart.click();

	}
}
