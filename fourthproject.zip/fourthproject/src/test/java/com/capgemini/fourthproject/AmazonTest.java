package com.capgemini.fourthproject;

import static org.junit.Assert.*;

import org.junit.Test;


public class AmazonTest extends FuntinalTest {

	@Test
	public void signUp() throws InterruptedException{
		
		driver.get("http://www.google.com");
		
		AmazonSearchPage searchPage = new AmazonSearchPage(driver);
		
		searchPage.googleSearch("Amazon");
		
		assertEquals("Amazon - Google Search", searchPage.driver.getTitle());
		searchPage.amazonSearch();
		searchPage.productSerach("Redmi 7");
		searchPage.selectingProductInList();
		Thread.sleep(2000);
		searchPage.switchWindow();

		ProductPage product= new ProductPage(driver);
		product.addToCart();
		Thread.sleep(5000);

	}	

}
