package com.capgemini.fourthproject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProductPage extends PageObject {

	@FindBy(id = "add-to-cart-button")
	private WebElement cart;
	
	public ProductPage(WebDriver driver) {
		super(driver);
	}
	
		
	public void addToCart() {
		this.cart.click();
	}

}
