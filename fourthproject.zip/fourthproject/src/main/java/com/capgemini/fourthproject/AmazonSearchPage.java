package com.capgemini.fourthproject;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AmazonSearchPage extends PageObject {

	@FindBy(name = "q")
	private WebElement searchBox1;

	@FindBy(xpath = "//*[text()='Amazon.in']")
	private WebElement searchBox2;

	@FindBy(xpath = "//input[@id='twotabsearchtextbox']")
	private WebElement productSearch;

	@FindBy(partialLinkText = "Redmi 7")
	private WebElement selectProduct;

	public AmazonSearchPage(WebDriver driver) {
		super(driver);

	}

	public void googleSearch(String searchBox1) {
		this.searchBox1.clear();
		this.searchBox1.sendKeys(searchBox1);
		this.searchBox1.submit();
	}

	public void amazonSearch() {
		this.searchBox2.click();

	}

	public void productSerach(String product) {
		this.productSearch.clear();
		this.productSearch.sendKeys(product);
		this.productSearch.submit();
	}

	public void selectingProductInList() {
		this.selectProduct.click();
	}

	public void switchWindow() {

		Set<String> handles = driver.getWindowHandles();
		String handle1 = driver.getWindowHandle();
		handles.remove(handle1);

		String handle = handles.iterator().next();
		String handle2 = "";
		if (handle != handle1) {
			handle2 = handle;
			driver.switchTo().window(handle2);
			
		}
	}

}
