package com.cg.repo;

import com.cg.beans.Account;

public interface AccountRepo {
	
	boolean save(Account account);
	
	Account searchAccount(int Accountnumber);
}
