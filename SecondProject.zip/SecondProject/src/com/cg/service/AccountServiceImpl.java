package com.cg.service;

import java.util.LinkedList;

import com.cg.beans.Account;
import com.cg.exception.InsufficientBalanceException;
import com.cg.exception.InsufficientOpeningBalanceException;
import com.cg.exception.InvalidAccountNumberException;
import com.cg.repo.AccountRepo;

public class AccountServiceImpl implements AccountService {
	LinkedList<Account> accounts = new LinkedList<>();
	
	AccountRepo accountRepo;

	public AccountServiceImpl(AccountRepo accountRepo) {
		// TODO Auto-generated constructor stub
		super();
		this.accountRepo =  accountRepo;
	}

	@Override
	public Account createAccount(int accountNumber, int amount) throws InsufficientOpeningBalanceException {
		if(amount >= 500) {
		Account account = new Account(accountNumber, amount);

		accounts.add(account);
		
		/*
		 * account.setAccountNumber(accountNumber); account.setAmount(amount);
		 */
		if(accountRepo.save(account)) {
			return account;
		}

		return null;
		}
		throw new InsufficientOpeningBalanceException();
	}

	public Account searchAccount(int accountNumber) throws InvalidAccountNumberException {

		for (Account account : accounts) {
			if (account.getAccountNumber() == accountNumber) {
				return account;
			}
		}
		
		throw new InvalidAccountNumberException();

	}

	@Override
	public String withdrawAmount(int accountNumber, int amount)
			throws InvalidAccountNumberException, InsufficientBalanceException {
		Account account = searchAccount(accountNumber);

		if ((account.getAmount() - amount) >= 0) {
			account.setAmount(account.getAmount() - amount);
			return "Amount is withdrawed successfully";
		}

		throw new InsufficientBalanceException();
	}
	@Override
	public String depositeAmount(int accountNumber, int amount)
			throws InvalidAccountNumberException {
		Account account = searchAccount(accountNumber);

			account.setAmount(account.getAmount() + amount);
			return "Amount is deposited successfully";
			}

	
	
}
