package com.cg.service;

import com.cg.beans.Account;
import com.cg.exception.InsufficientBalanceException;
import com.cg.exception.InsufficientOpeningBalanceException;
import com.cg.exception.InvalidAccountNumberException;

public interface AccountService {

	Account createAccount(int accountNumber, int amount) throws InsufficientOpeningBalanceException;

	Account searchAccount(int accountNumber) throws InvalidAccountNumberException;

		
	String withdrawAmount(int accountNumber, int amount)
			throws InvalidAccountNumberException, InsufficientBalanceException;

	String depositeAmount(int accountNumber, int amount)
			throws InvalidAccountNumberException;

}