package com.cg.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.beans.Account;
import com.cg.exception.InsufficientBalanceException;
import com.cg.exception.InsufficientOpeningBalanceException;
import com.cg.exception.InvalidAccountNumberException;
import com.cg.repo.AccountRepo;
import com.cg.service.AccountService;
import com.cg.service.AccountServiceImpl;

public class AccountServiceTest {

	@Mock
	AccountRepo accountRepo;
	
	AccountService accountService;
	
	@Before
	public void setup() throws Exception	{
		MockitoAnnotations.initMocks(this);
		accountService = new AccountServiceImpl(accountRepo);
	}
	
	@Test(expected = InsufficientOpeningBalanceException.class)
	public void whenTheAmountIsLessThanFiveHundredSystemShouldThrowException() throws InsufficientOpeningBalanceException {
		accountService.createAccount(101, 400);
	}
	
	
	@Test
	public void WhenTheValidInfoIsPassedAccountShouldBeCreatedSuccessfully() throws InsufficientOpeningBalanceException {
		Account account = new Account();
		account.setAccountNumber(101);
		account.setAmount(500);
		
		when(accountRepo.save(account)).thenReturn(true);
		
		assertEquals(account, accountService.createAccount(101, 500));
	}
	
	
	@Test(expected = InvalidAccountNumberException.class)
	public void whenTheAccountNumberIsNotFoundSystemShouldThrowException() throws InvalidAccountNumberException, InsufficientBalanceException {
		accountService.withdrawAmount(103,500);
	}
	
	
	@Test(expected = InsufficientBalanceException.class)
	public void whenTheWithdrawBalanceIsNotSufficientSystemShouldThrowException() throws InvalidAccountNumberException, InsufficientBalanceException, InsufficientOpeningBalanceException {
		
		  accountService.createAccount(102,500);
		
		accountService.withdrawAmount(102,600);
	}
	
	@Test
	public void whenTheWithdrawAmountIsSuccessfull() throws InvalidAccountNumberException, InsufficientBalanceException, InsufficientOpeningBalanceException {
		accountService.createAccount(103,500); 
		
		accountService.withdrawAmount(103,100);
		
		assertEquals("Amount is withdrawed successfully",accountService.withdrawAmount(103, 100));

	}
	
	@Test(expected = InvalidAccountNumberException.class)
	public void whenTheAccountNumberIsNotFoundWhileDepositingSystemShouldThrowException() throws InvalidAccountNumberException, InsufficientBalanceException {
		accountService.depositeAmount(103,5000);
	}
	
	
	@Test
	public void whenTheDepositeAmountIsSuccessfull() throws InvalidAccountNumberException, InsufficientOpeningBalanceException {
		
		accountService.createAccount(104,500); 
		
		accountService.depositeAmount(104,100);
		
		assertEquals("Amount is deposited successfully", accountService.depositeAmount(104, 100));

	}

	
	
	
}
