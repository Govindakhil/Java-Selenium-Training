package com.cg.exception;

public class InsufficientBalanceException extends Exception{

}
