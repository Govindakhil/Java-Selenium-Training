package com.cg.exception;

public class InvalidAccountNumberException extends Exception {

}
