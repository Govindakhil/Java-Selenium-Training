package com.cg.exception;

public class InsufficientOpeningBalanceException extends Exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
